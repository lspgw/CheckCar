package cn.edu.nbpt.android;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;
import com.android.volley.toolbox.Volley;

public class BusActivity extends AppCompatActivity {

    private NetworkImageView map;
    private TextView name;
    private Button btnNext;
    private TextView ticket;
    private TextView meter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus);
        final Intent intent = getIntent();
        map = (NetworkImageView) findViewById(R.id.map);
        name = (TextView) findViewById(R.id.name);
        btnNext = (Button) findViewById(R.id.btn_next);
        ticket = (TextView) findViewById(R.id.ticket);
        meter = (TextView) findViewById(R.id.meter);
        JSONObject jsonObject = JSONObject.parseObject(intent.getStringExtra("data"));
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        ImageLoader imageLoader = new ImageLoader(requestQueue, new ImageLoader.ImageCache() {
            @Override
            public Bitmap getBitmap(String url) {
                return null;
            }

            @Override
            public void putBitmap(String url, Bitmap bitmap) {

            }
        });
        map.setImageUrl(jsonObject.getString("map"), imageLoader);
        ticket.setText("￥ " + jsonObject.getIntValue("ticket"));
        meter.setText(jsonObject.getIntValue("mileage") + "km");
        Log.i("TAG", jsonObject.toJSONString());
        String str = jsonObject.getString("time");
        JSONArray jsonArray = JSONArray.parseArray(str);
        JSONObject jsonObject2 = jsonArray.getJSONObject(0);
        JSONObject jsonObject3 = jsonArray.getJSONObject(1);
        name.setText(jsonObject2.getString("site") + "---------" + jsonObject3.getString("site"));
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(BusActivity.this, SelectDate.class);
                intent1.putExtra("data", intent.getStringExtra("data"));
                startActivity(intent1);
            }
        });
    }
}
