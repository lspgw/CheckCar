package cn.edu.nbpt.android;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;
import com.android.volley.toolbox.Volley;

public class DetailActivity extends AppCompatActivity {
    private TextView tvDesc;
    private NetworkImageView pic;
    private TextView tvPhone;
    JSONObject jsonObject;
    private ImageView[] images = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        Intent intent = getIntent();
        String stringExtra = intent.getStringExtra("data");
        jsonObject = JSONObject.parseObject(stringExtra);
        images = new ImageView[]{
                (ImageView) findViewById(R.id.imageView),
                (ImageView) findViewById(R.id.imageView2),
                (ImageView) findViewById(R.id.imageView3),
                (ImageView) findViewById(R.id.imageView4),
                (ImageView) findViewById(R.id.imageView5),
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        tvDesc = (TextView) findViewById(R.id.tv_desc);
        pic = (NetworkImageView) findViewById(R.id.pic);
        tvPhone = (TextView) findViewById(R.id.tv_phone);
        tvDesc.setText(jsonObject.getString("info"));
        tvPhone.setText(jsonObject.getString("tel"));
        for (int i = 0; i < jsonObject.getIntValue("rating"); i++) {
            images[i].setImageResource(R.mipmap.rating2);
        }

        ImageLoader imageLoader = new ImageLoader(requestQueue, new ImageLoader.ImageCache() {
            @Override
            public Bitmap getBitmap(String url) {
                return null;
            }

            @Override
            public void putBitmap(String url, Bitmap bitmap) {

            }
        });
        pic.setImageUrl(jsonObject.getString("img"), imageLoader);
        tvPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + jsonObject.getString("tel")));
                startActivity(intent1);
            }
        });

    }
}
