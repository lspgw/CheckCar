package cn.edu.nbpt.android;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.NetworkImageView;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class TravelActivity extends AppCompatActivity {
    private GridView girdList;
    ArrayList<Map<String, Object>> mdata = new ArrayList<>();
    JSONObject data;
    JSONArray arr;
    Map<String, Object> map;
    RequestQueue requestQueue;
    int i;
    Handler handler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what) {
                case 1:
                    try {
                        arr = (JSONArray) msg.obj;
                        for (i = 0; i < arr.length(); i++) {
                            data = arr.getJSONObject(i);
                            arr.getJSONObject(i);
                            map = new HashMap<>();
                            map.put("id", data.getInt("id"));
                            map.put("name", data.getString("name"));
                            map.put("ticket", "票价 ￥" + data.getInt("ticket"));
                            map.put("info", data.getString("info"));
                            map.put("tel", data.getString("tel"));
                            map.put("rating", data.getInt("rating"));
                            map.put("img", getString(R.string.base_url) + data.getString("img"));
                            mdata.add(map);
                        }
                        bind();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    break;
            }
        }
    };

    protected void bind() {
        SimpleAdapter simpleAdapter = new SimpleAdapter(getApplicationContext(), mdata, R.layout.item,
                new String[]{
                        "img", "name", "ticket"
                }, new int[]{R.id.img, R.id.name, R.id.ticket});
        simpleAdapter.setViewBinder(new SimpleAdapter.ViewBinder() {
            @Override
            public boolean setViewValue(View view, Object data, String textRepresentation) {
                if (view instanceof NetworkImageView) {
                    NetworkImageView networkImageView = (NetworkImageView) view.findViewById(R.id.img);
                    ImageLoader imageLoader = new ImageLoader(requestQueue, new ImageLoader.ImageCache() {
                        @Override
                        public Bitmap getBitmap(String url) {
                            return null;
                        }

                        @Override
                        public void putBitmap(String url, Bitmap bitmap) {

                        }
                    });
                    networkImageView.setImageUrl(data.toString(), imageLoader);
                    return true;
                }
                return false;
            }
        });
        girdList.setAdapter(simpleAdapter);
        girdList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(TravelActivity.this, DetailActivity.class);
                intent.putExtra("data", com.alibaba.fastjson.JSONObject.toJSONString(mdata.get(position)));
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_travel);
        girdList = (GridView) findViewById(R.id.gird_list);
        requestQueue = Volley.newRequestQueue(getApplicationContext());

        try {
            setMdata();

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    //1.volley获取数据->handler处理（volley获取图片->handler）
    public void setMdata() throws JSONException {
        SharedPreferences sharedPreferences = getSharedPreferences("session", MODE_PRIVATE);
        String username = sharedPreferences.getString("UserName", "");
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("UserName", username);

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, getString(R.string.base_url) + getString(R.string.GetSpotInfo), jsonObject, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    if (response.getString("RESULT").equals("S")) {
                        Message msg = new Message();
                        msg.what = 1;
                        msg.obj = response.getJSONArray("ROWS_DETAIL");
                        handler.sendMessage(msg);


                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "网络错误", Toast.LENGTH_SHORT).show();
            }
        });
        requestQueue.add(request);
    }


}
