package cn.edu.nbpt.android;

import android.content.Context;
import android.util.AttributeSet;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class TabwebView extends WebView {
    public TabwebView(Context context) {
        this(context, null);
    }

    public TabwebView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }
    public TabwebView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }
    public void init(){
        WebSettings webSettings=getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setSupportZoom(false);
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        webSettings.setBuiltInZoomControls(false);
    }
}
