package cn.edu.nbpt.android;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;

public class Sure extends AppCompatActivity {
    Intent intent;
    private TextView textView10;
    private Button button2;
    private TextView textView18;
    private TextView textView19;
    private TextView textView20;
    private TextView textView21;
    int id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sure);
        intent = getIntent();
        intent.getStringExtra("data");

        String stringExtra1 = intent.getStringExtra("phone");
        String stringExtra = intent.getStringExtra("start_site");
        intent.getStringExtra("phone");
        JSONObject jsonObject = JSONObject.parseObject(intent.getStringExtra("data"));
        id = jsonObject.getIntValue("id");
        JSONArray Json = jsonObject.getJSONArray("time");
        JSONObject jsonObject2 = Json.getJSONObject(0);
        JSONObject jsonObject1 = Json.getJSONObject(1);


        textView10 = (TextView) findViewById(R.id.textView10);
        button2 = (Button) findViewById(R.id.button2);
        textView18 = (TextView) findViewById(R.id.textView18);
        textView19 = (TextView) findViewById(R.id.textView19);
        textView20 = (TextView) findViewById(R.id.textView20);
        textView21 = (TextView) findViewById(R.id.textView21);

        textView10.setText(jsonObject2.getString("site") + "-----------" + jsonObject1.getString("site"));
        textView18.setText(intent.getStringExtra("name"));
        textView19.setText(stringExtra1);
        textView20.setText(stringExtra);
        JSONArray jsonArray = JSONArray.parseArray(intent.getStringExtra("date"));
        StringBuilder str = new StringBuilder();
        for (int i = 0; i < jsonArray.size(); i++) {
            String string = jsonArray.getString(i);
            str
                    .append(string.substring(0, 4))
                    .append("-")
                    .append(string.substring(4, 6))
                    .append("-")
                    .append(string.substring(6, 8))
                    .append(",");
        }
        textView21.setText(str.substring(0, str.length() -1));
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                org.json.JSONObject jsonObject3 = new org.json.JSONObject();
                SharedPreferences sharedPreferences = getSharedPreferences("session", MODE_PRIVATE);
                try {
                    jsonObject3.put("UserName", sharedPreferences.getString("UserName",""));
                    jsonObject3.put("Id", id);
                    jsonObject3.put("PhoneNumber",intent.getStringExtra("phone"));
                    jsonObject3.put("StartSite", intent.getStringExtra("start_site"));
                    jsonObject3.put("EndSite", intent.getStringExtra("end_site"));
                    jsonObject3.put("BusDate", textView21.getText().toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, getString(R.string.base_url) + getString(R.string.SetUserBusLine), jsonObject3, new Response.Listener<org.json.JSONObject>() {
                    @Override
                    public void onResponse(org.json.JSONObject response) {
                        try {
                            if (response.getString("RESULT").equals("S")) {

                                Toast.makeText(Sure.this, "提交成功", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), ListActivity.class);
                                startActivity(intent);
                                finish();
                            } else {
                                Toast.makeText(Sure.this, "提交失败", Toast.LENGTH_SHORT).show();

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, null);
                requestQueue.add(request);
            }
        });


    }
}
