package cn.edu.nbpt.android;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class StartActivity extends AppCompatActivity {
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences sharedPreferences = getSharedPreferences("session", MODE_PRIVATE);
        String userName = sharedPreferences.getString("UserName", "");
        String userPwd = sharedPreferences.getString("UserPwd", "");


        /**
         * 判断是否为空
         */
        if (!userName.isEmpty() && !userPwd.isEmpty()) {
            RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("UserName", userName);
                jsonObject.put("UserPwd", userPwd);

            } catch (JSONException e) {
                e.printStackTrace();
            }

            JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, getString(R.string.base_url) + getString(R.string.user_login), jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                String str = response.getString("RESULT");
                                if (str.equals("S")) {
                                    intent = new Intent(StartActivity.this, ListActivity.class);
                                    startActivity(intent);

                                } else {
                                    intent = new Intent(StartActivity.this, LoginActivity.class);
                                    startActivity(intent);

                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                                intent = new Intent(StartActivity.this, LoginActivity.class);
                                startActivity(intent);

                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            intent = new Intent(StartActivity.this, LoginActivity.class);
                            startActivity(intent);

                        }
                    });
            requestQueue.add(request);
        } else {
            intent = new Intent(StartActivity.this, LoginActivity.class);
            startActivity(intent);

        }
    }
}
