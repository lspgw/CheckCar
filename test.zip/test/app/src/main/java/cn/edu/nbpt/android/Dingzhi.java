package cn.edu.nbpt.android;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.alibaba.fastjson.JSON;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class Dingzhi extends AppCompatActivity {
    ArrayList<Map<String, Object>> mData = new ArrayList<>();
    ArrayList<Map<String, Object>> mData2 = new ArrayList<>();

    GridView ls;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dingzhi);
        ls = (GridView) findViewById(R.id.List);
        try {
            getData();
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private void getData() throws JSONException {
        SharedPreferences sp = getSharedPreferences("session", MODE_PRIVATE);
        String username = sp.getString("UserName", "");
        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("Line", 0);
        jsonObject.put("UserName", username);
        final JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, getString(R.string.base_url) + getString(R.string.GetBusInfo), jsonObject,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            if (response.getString("RESULT").equals("S")) {
                                JSONArray jsonArray = response.getJSONArray("ROWS_DETAIL");
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                    Map<String, Object> map = new HashMap<>();
                                    Map<String, Object> map2 = new HashMap<>();
                                    map.put("id", jsonObject1.getInt("id"));
                                    map.put("name", jsonObject1.getString("name"));
                                    map.put("map", getString(R.string.base_url) + jsonObject1.getString("map"));
                                    map.put("mileage", jsonObject1.getString("mileage"));
                                    map.put("ticket", jsonObject1.getInt("ticket"));
                                    map.put("sites", jsonObject1.getJSONArray("sites").toString());
                                    map.put("time", jsonObject1.getJSONArray("time").toString());
                                    mData.add(map);

                                    JSONArray jsonArray1 = jsonObject1.getJSONArray("time");
                                    JSONObject jsonObject2 = jsonArray1.getJSONObject(0);
                                    JSONObject jsonObject3 = jsonArray1.getJSONObject(1);
                                    map2.put("name", jsonObject1.getString("name"));
                                    map2.put("n", jsonObject2.getString("site") + "---------" + jsonObject3.getString("site"));
                                    map2.put("mileage", "票价：￥" + jsonObject1.getInt("ticket") + " 里程：" + jsonObject1.getString("mileage") + "km");
                                    map2.put("startTIme", jsonObject2.getString("starttime"));
                                    map2.put("endTIme", jsonObject2.getString("endtime"));
                                    map2.put("time", R.mipmap.ic_menu_recent_history);
                                    map2.put("right", R.mipmap.right);

                                    mData2.add(map2);


                                }

                                SimpleAdapter simpleAdapter = new SimpleAdapter(getApplicationContext(), mData2, R.layout.bus_list, new String[]{
                                        "name", "n", "mileage", "startTIme", "endTIme", "time", "time", "right"
                                }, new int[]{
                                        R.id.which, R.id.name, R.id.meter, R.id.startTIme, R.id.endTIme, R.id.imageView6, R.id.imageView8, R.id.imageView7
                                });
                                ls.setAdapter(simpleAdapter);

                                ls.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                    @Override
                                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                        Intent intent = new Intent(Dingzhi.this, BusActivity.class);
                                        intent.putExtra("data", JSON.toJSONString(mData.get(position)));
                                        startActivity(intent);
                                    }
                                });

                            } else {
                                Toast.makeText(getApplicationContext(), "登陆失败", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            Toast.makeText(getApplicationContext(), "登陆失败", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                Toast.makeText(getApplicationContext(), "登陆失败", Toast.LENGTH_SHORT).show();
            }
        });


        queue.add(jsonObjectRequest);
    }
}
