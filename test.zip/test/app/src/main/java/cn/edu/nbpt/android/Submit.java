package cn.edu.nbpt.android;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import java.util.List;

public class Submit extends AppCompatActivity {

    private TextView textView8;
    private EditText editText;
    private EditText editText2;
    private Spinner spinner;
    private Spinner spinner2;
    private Button button;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submit);
        textView8 = (TextView) findViewById(R.id.textView8);
        editText = (EditText) findViewById(R.id.editText);
        editText2 = (EditText) findViewById(R.id.editText2);
        spinner = (Spinner) findViewById(R.id.spinner);
        spinner2 = (Spinner) findViewById(R.id.spinner2);
        intent = getIntent();
        JSONObject jsonObject = JSONObject.parseObject(intent.getStringExtra("data"));
        JSONArray Json = jsonObject.getJSONArray("time");
        JSONObject jsonObject2 = Json.getJSONObject(0);
        JSONObject jsonObject1 = Json.getJSONObject(1);

        textView8.setText(jsonObject2.getString("site") + "-----------" + jsonObject1.getString("site"));
        button = (Button) findViewById(R.id.button);
        String str = intent.getStringExtra("data");
        List<String> s = JSONArray.parseArray(JSON.toJSONString(JSONObject.parseObject(str).getJSONArray("sites")), String.class);
        ArrayAdapter<String> simpleAdapter = new ArrayAdapter<String>(getApplicationContext(), R.layout.support_simple_spinner_dropdown_item, s);
        spinner.setAdapter(simpleAdapter);
        spinner2.setAdapter(simpleAdapter);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String user = editText.getText().toString();
                String phone = editText2.getText().toString();
                String start_site = spinner.getSelectedItem().toString();
                String end_site = spinner2.getSelectedItem().toString();
                Intent intent1 = new Intent(Submit.this, Sure.class);
                intent1.putExtra("data", intent.getStringExtra("data"));
                intent1.putExtra("name", user);
                intent1.putExtra("phone", phone);
                intent1.putExtra("start_site", start_site);
                intent1.putExtra("end_site", end_site);
                intent1.putExtra("date", intent.getStringExtra("date"));

                startActivity(intent1);
            }
        });

    }
}
