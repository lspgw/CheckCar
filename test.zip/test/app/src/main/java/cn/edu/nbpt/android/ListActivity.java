package cn.edu.nbpt.android;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ListActivity extends AppCompatActivity {
    private Button btnTravelSsistant;
    private Button btnLifeTrip;
    private Button btnVehicleViolation;
    private Button btnPersonalCenter;
    private Button btnCustomizedShuttleBus;
    private Button btnDataAnalysis;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        btnTravelSsistant = (Button) findViewById(R.id.btn_travel_ssistant);
        btnLifeTrip = (Button) findViewById(R.id.btn_life_trip);
        btnVehicleViolation = (Button) findViewById(R.id.btn_vehicle_violation);
        btnPersonalCenter = (Button) findViewById(R.id.btn_personal_center);
        btnCustomizedShuttleBus = (Button) findViewById(R.id.btn_customized_shuttle_bus);
        btnDataAnalysis = (Button) findViewById(R.id.btn_data_analysis);
        btnTravelSsistant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ListActivity.this, TravelActivity.class));
            }
        });
        btnCustomizedShuttleBus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ListActivity.this, Dingzhi.class));
            }
        });
    }
}
