package cn.edu.nbpt.android;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.alibaba.fastjson.JSON;
import com.haibin.calendarview.Calendar;
import com.haibin.calendarview.CalendarView;

import java.util.ArrayList;
import java.util.List;


public class SelectDate extends AppCompatActivity {
    private CalendarView calendarView;
    private Button btnNext;
    private TextView date;
    Intent intent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_date);
        intent = getIntent();
        calendarView = (CalendarView) findViewById(R.id.calendarView);
        date = (TextView) findViewById(R.id.date);
        btnNext = (Button) findViewById(R.id.btn_next);
        calendarView.setSelectMultiMode();
        calendarView.setOnCalendarSelectListener(new CalendarView.OnCalendarSelectListener() {
            @Override
            public void onCalendarOutOfRange(Calendar calendar) {

            }

            @Override
            public void onCalendarSelect(Calendar calendar, boolean isClick) {
                List<Calendar> calendars = calendarView.getMultiSelectCalendars();

                if (calendars.indexOf(calendar) == -1) {
                    calendarView.putMultiSelect(calendar);
                } else
                    calendarView.removeMultiSelect(calendar);
                if (calendars.size() != 0) {
                    StringBuilder dt = new StringBuilder();
                    for (int i = 0; i < calendars.size(); i++) {
                        Calendar calendar1 = calendars.get(i);
                        dt.append(calendar1.getYear()).append("-").append(calendar1.getMonth()).append("-").append(calendar1.getDay()).append("，");
                    }

                    date.setText(dt.toString().substring(0, dt.toString().length() - 1));
                }
            }
        });
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<Calendar> cl = calendarView.getMultiSelectCalendars();
                List<String> date = new ArrayList<String>();
                Intent intent1 = new Intent(getApplicationContext(), Submit.class);
                for (int i = 0; i < cl.size(); i++) {
                    date.add(cl.get(i).toString());
                }
                intent1.putExtra("date", JSON.toJSONString(date));
                intent1.putExtra("data", intent.getStringExtra("data"));
                startActivity(intent1);
            }
        });
    }
}
